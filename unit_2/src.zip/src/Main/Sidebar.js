import Nav from '../Header/Nav';

function Sidebar() {
  return (
    <>
      <ul>
        <li>Страница 1</li>
        <li>Страница 2</li>
        <li>Страница 3</li>
      </ul>
    </>
  );
}

export default Sidebar;
