function Error() {
  return (
    <>
      <h2>404 Page not found</h2>
    </>
  );
}
export default Error;
