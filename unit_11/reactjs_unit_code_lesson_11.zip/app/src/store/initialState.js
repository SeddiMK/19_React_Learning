const initialState = {
    goods: [
        {
            id: 'dboses',
            title: 'Кресло для геймеров Hator Sport Light Black',
            image: 'https://i2.rozetka.ua/goods/15985714/hator_htc_910_images_15985714844.jpg'
        }
    ]
};

export default initialState;