export const addGoods = (id, title, image) => ({
  type: 'ADD_GOODS',
  id,
  title,
  image
});

export const ShowGoods = {
  SHOW_ALL: 'SHOW_ALL',
}

