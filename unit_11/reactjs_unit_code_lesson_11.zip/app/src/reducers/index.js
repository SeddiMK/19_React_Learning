import { combineReducers } from 'redux'
import goods from './goods';

export default combineReducers({
  goods
})
